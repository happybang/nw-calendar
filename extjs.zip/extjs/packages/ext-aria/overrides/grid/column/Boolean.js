Ext.define('Ext.aria.grid.column.Boolean', {
    override: 'Ext.grid.column.Boolean',
    requires: [
        'Ext.aria.grid.column.Column'
    ]
});
