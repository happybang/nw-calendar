Ext.define('Ext.aria.grid.column.Number', {
    override: 'Ext.grid.column.Number',
    
    requires: [
        'Ext.aria.grid.column.Column'
    ]
});
