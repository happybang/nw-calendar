Ext.define('Ext.aria.form.field.Spinner', {
    override: 'Ext.form.field.Spinner',
    
    requires: [
        'Ext.aria.form.field.Trigger'
    ]
});
